#!/bin/bash

# рабочая директория
cd `dirname $0`

# пауза перед началом работы, чтобы сеть прогрузилась
echo "Timeout 30 sec..."
sleep 30

echo
echo START

while true; do
	source "./RigOnline.sh"
done