#!/bin/sh
./miner --algo 144_5 --pers BitcoinZ --server mine-btcz-euro.equipool.1ds.us --port 50063 --user t1duyePXARPE7pm7WdJxxeA45o6efUk3cWR.rig0 --pass x
