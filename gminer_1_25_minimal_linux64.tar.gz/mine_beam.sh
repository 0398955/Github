#!/bin/sh
./miner --algo 150_5 --server beam.sparkpool.com --port 2222 --ssl 1 --user 100fd5cb7f85d33f74ef78f89e78cd0d5a63fc4965476eea4f77f024a57d99fa55.rig0
