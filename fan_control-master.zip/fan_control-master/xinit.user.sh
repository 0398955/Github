screen -dmS fan /home/user/fan.sh
