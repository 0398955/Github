#!/bin/sh
./miner --algo 210_9 --pers AION0PoW --server aion-eu.luxor.tech --port 3366 --user 0xa07978089c76e2010720bec8400f05530cd946a567dc0fd9b862d83a45681f7c --pass x
