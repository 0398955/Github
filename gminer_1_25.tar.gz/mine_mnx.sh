#!/bin/sh
./miner --algo 96_5 --pers ZcashPoW --server mnx-eu.forgetop.com --port 5052 --user XSujWA99m3dPgCepUeSkvn5ro5TSqGaXEY.rig0 --pass x
