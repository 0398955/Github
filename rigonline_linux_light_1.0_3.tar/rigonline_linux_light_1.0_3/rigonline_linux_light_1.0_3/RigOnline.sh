#!/bin/bash

# удаляем лог
if [[ -f "./log.txt" ]]; then rm "log.txt"; fi
	
# берем настройки
if [[ -f "./rig.ini" ]]; then source "./rig.ini"; fi
if [[ -f "./secret.ini" ]]; then source "./secret.ini"; fi

# # если первый вызов
if [[ -z ${restart} ]]; then

	restart=1

	# берем настройки
	if [[ -f "./config.ini" ]]; then source "./config.ini"; fi

	echo
	echo ---------------------------
	echo SEND RESTART TO RIGONLINE.RU ...

	# дергаем урл перезагрузки на сервисе
	wget -q -T 10 -O log.txt "https://rigonline.ru/api/?email=${email}&secret=${secret}&rig=${rig}&restart=y" --no-check-certificate
	export RC=$?
	chmod +x *.*

else

	# обновление конфига
	echo
	echo ---------------------------
	echo UPDATE CONFIG FROM RIGONLINE.RU ...

 	wget -q -T 10 -O config.ini "https://rigonline.ru/api/get.php?type=config&email=${email}&rig=${rig}" --no-check-certificate
	export RC=$?
	chmod +x *.*
	if [ "$RC" = "0" ]; then
		echo UPDATE DONE
	else
		echo ERROR: FAILED TO UPDATE CONFIG
	fi

	echo ---------------------------

 	# берем настройки
	if [[ -f "./config.ini" ]]; then source "./config.ini"; fi

	echo
	echo ---------------------------
	echo SEND DATA TO RIGONLINE.RU ...
	# дергаем урл на сервисе
	wget -q -T 10 -O log.txt "https://rigonline.ru/api/?email=${email}&secret=${secret}&rig=${rig}" --no-check-certificate
	export RC=$?
	chmod +x *.*

fi

export RC=$?
if [ "$RC" = "0" ]; then
	echo `cat log.txt`
else
	echo ERROR
fi

echo ---------------------------

# если первый вызов
if [[ $restart = 1 ]]; then
	restart=0
else
	# пауза
	echo
	echo PAUSE $pause
	sleep $pause
fi
